import React, { useState } from "react";
import "bootstrap/dist/css/bootstrap.min.css";

const FacultyCRUD = () => {
  const [faculties, setFaculties] = useState([
    { id: 1, name: "Dr. A. Sharma", department: "CSE", experience: 10, qualification: "PhD", contact: 9876543210 },
    { id: 2, name: "Prof. B. Mehta", department: "IT", experience: 8, qualification: "M.Tech", contact: 8765432109 },
    { id: 3, name: "Dr. C. Patel", department: "ECE", experience: 12, qualification: "PhD", contact: 7654321098 },
    { id: 4, name: "Prof. D. Verma", department: "ME", experience: 7, qualification: "M.Tech", contact: 6543210987 },
    { id: 5, name: "Dr. E. Gupta", department: "Civil", experience: 15, qualification: "PhD", contact: 5432109876 },
  ]);

  // Delete Faculty
  const deleteFaculty = (id) => {
    setFaculties(faculties.filter((faculty) => faculty.id !== id));
  };

  return (
    <div className="container mt-4">
      <h2 className="text-center mb-4">Faculty List</h2>

      {/* Display Faculties */}
      <table className="table table-bordered table-striped">
        <thead className="table-dark">
          <tr>
            <th>ID</th>
            <th>Name</th>
            <th>Department</th>
            <th>Experience (Years)</th>
            <th>Qualification</th>
            <th>Contact</th>
            <th>Action</th>
          </tr>
        </thead>
        <tbody>
          {faculties.length > 0 ? (
            faculties.map((faculty) => (
              <tr key={faculty.id}>
                <td>{faculty.id}</td>
                <td>{faculty.name}</td>
                <td>{faculty.department}</td>
                <td>{faculty.experience}</td>
                <td>{faculty.qualification}</td>
                <td>{faculty.contact}</td>
                <td>
                  <button className="btn btn-danger btn-sm" onClick={() => deleteFaculty(faculty.id)}>Delete</button>
                </td>
              </tr>
            ))
          ) : (
            <tr>
              <td colSpan="7" className="text-center">No faculties available</td>
            </tr>
          )}
        </tbody>
      </table>
    </div>
  );
};

export default FacultyCRUD;
