import { useState } from 'react'
import reactLogo from './assets/react.svg'
import viteLogo from '/vite.svg'
import './App.css'
import ProductCRUD from'./Products'
import StudentCRUD from './Students'
import FacultyCRUD from './faculties'

function App() {
  const [count, setCount] = useState(0)

  return (
    <>
        <ProductCRUD/>
        <StudentCRUD/>
        <FacultyCRUD/>
    </>
  )
}

export default App
